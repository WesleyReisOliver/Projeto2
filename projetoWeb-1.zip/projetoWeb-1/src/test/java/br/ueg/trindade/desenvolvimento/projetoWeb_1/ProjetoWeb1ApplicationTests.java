package br.ueg.trindade.desenvolvimento.projetoWeb_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoWeb1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
